public interface Drawable {
    void draw();
}
