public class Triangle implements Drawable{
    @Override
    public void draw() {
        System.out.println("Drawing a Triangle");
    }
}
